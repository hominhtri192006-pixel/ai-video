"""AI video factory: iPhone photo -> Gemini -> narration -> video -> private release.
Does not send photos to fal.ai unless AI_MOTION=true and FAL_KEY exists.
"""
from __future__ import annotations
import base64
import json
import math
import os
from pathlib import Path
import random
import re
import shutil
import subprocess
import wave
from PIL import Image, ImageOps
from pillow_heif import register_heif_opener
import requests

ROOT = Path(__file__).resolve().parent
WORK = ROOT / '.tmp'
OUTPUT = ROOT / 'output'
MODEL = os.environ.get('GEMINI_MODEL', 'gemini-3.5-flash-lite')


def cmd(*args):
    p = subprocess.run([str(x) for x in args], capture_output=True, text=True)
    if p.returncode:
        print(p.stdout[-2500:])
        print(p.stderr[-4500:])
        raise RuntimeError(f'Command failed: {args[0]} (code {p.returncode})')
    return p.stdout.strip()


def input_image():
    register_heif_opener()
    types = {'.jpg', '.jpeg', '.png', '.webp', '.heic', '.heif'}
    images = [p for p in (ROOT/'inbox').iterdir() if p.suffix.lower() in types]
    if len(images) != 1:
        raise ValueError(f'Expected exactly 1 image inside inbox/. Found {len(images)}. Remove older photos before uploading a new one.')
    pic = images[0]
    with Image.open(pic) as im:
        im = ImageOps.exif_transpose(im).convert('RGB')
        im.thumbnail((1600, 1600))
        im.save(WORK / 'photo.jpg', quality=89, optimize=True)
    print(f'Image: {pic.name}, optimized as photo.jpg')
    return WORK / 'photo.jpg'


def generate_script(image):
    api_key = os.environ.get('GEMINI_API_KEY', '').strip()
    if not api_key:
        raise RuntimeError('Missing GEMINI_API_KEY. Add it in Settings > Secrets and variables > Actions.')
    instruction = (
        'Bạn đang dựng video TikTok tiếng Việt từ DUY NHẤT 1 ảnh. '
        'Đọc ảnh và sáng tạo kịch bản video giải thích hoặc kể chuyện 25-30 giây. '
        'Chỉ mô tả sự thật nhìn được; không bịa thông số, không nêu sự thật không có chứng cứ. '
        'Trả về đúng JSON gồm 3 khóa: title (tiêu đề 6-10 từ), '
        'narration (60-75 từ tiếng Việt tự nhiên, không xuống dòng), '
        'visual_prompt (một prompt bằng tiếng Anh để tạo chuyển động cinematic từ chính ảnh, không thay đổi chủ thể). '
        'Không đưa hướng dẫn ngoài JSON.'
    )
    blob = base64.b64encode(image.read_bytes()).decode('ascii')
    url = f'https://generativelanguage.googleapis.com/v1beta/models/{MODEL}:generateContent'
    payload = {
        'contents': [{'parts': [
            {'text': instruction},
            {'inline_data': {'mime_type': 'image/jpeg', 'data': blob}},
        ]}],
        'generationConfig': {'responseMimeType': 'application/json', 'temperature': 0.65},
    }
    response = requests.post(url, headers={'x-goog-api-key':api_key}, json=payload, timeout=100)
    if response.status_code >= 400:
        raise RuntimeError(f'Gemini API HTTP {response.status_code}: {response.text[:700]}')
    obj = response.json()
    try:
        raw = ''.join(x.get('text','') for x in obj['candidates'][0]['content']['parts'])
        raw = re.sub(r'^```(?:json)?\s*|\s*```$', '', raw.strip())
        data = json.loads(raw)
        for key in ('title', 'narration', 'visual_prompt'):
            if not isinstance(data.get(key), str) or not data[key].strip():
                raise KeyError(key)
    except Exception as exc:
        raise RuntimeError(f'Gemini output not valid JSON: {str(obj)[:700]}') from exc
    (OUTPUT/'script.json').write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    print('Title:', data['title'])
    return data


def audio_tts(narration):
    cmd('edge-tts', '--voice', 'vi-VN-NamMinhNeural', '--rate', '+7%',
        '--text', narration, '--write-media', WORK/'speech.mp3',
        '--write-subtitles', WORK/'speech.srt')
    sec = float(cmd('ffprobe', '-v', 'error', '-show_entries', 'format=duration',
                   '-of', 'default=noprint_wrappers=1:nokey=1', WORK/'speech.mp3'))
    if sec < 2:
        raise RuntimeError('Speech is unexpectedly short.')
    if not (WORK/'speech.srt').exists() or not (WORK/'speech.srt').stat().st_size:
        raise RuntimeError('Subtitles not produced by edge-tts.')
    duration = max(30, math.ceil(sec + 1.5))
    print(f'Voice length: {sec:.1f}s; output: {duration}s')
    return duration


def make_music(duration):
    # Original synthesised ambient pad. No external copyrighted music download.
    sr = 16000
    chords = [[261.63,329.63,392.0], [196.0,246.94,392.0],
              [220.0,261.63,329.63], [174.61,220.0,349.23]]
    out = WORK/'ambient.wav'
    import struct
    with wave.open(str(out), 'wb') as wav:
        wav.setnchannels(1); wav.setsampwidth(2); wav.setframerate(sr)
        chunk = bytearray()
        for i in range(int(duration * sr)):
            t = i/sr
            idx = min(int(t//8)%4, 3)
            beat = t%8
            envelope = min(1, t/2.5, (duration-t)/2.5, beat+0.025, (8-beat)+0.025)
            envelope = max(.0, min(1.0, envelope))
            s = sum(math.sin(2*math.pi*f*t) for f in chords[idx])/3
            val = int(5000*s*envelope*(.8+.2*math.sin(2*math.pi*.15*t)))
            chunk.extend(struct.pack('<h', val))
            if len(chunk)>65536:
                wav.writeframesraw(chunk); chunk.clear()
        if chunk: wav.writeframesraw(chunk)


def visual(image, prompt, duration):
    use_motion = os.environ.get('AI_MOTION','').lower() in {'yes','true','1'}
    file = None
    if use_motion:
        import fal_client
        if not os.environ.get('FAL_KEY'):
            raise RuntimeError('AI_MOTION=true but FAL_KEY missing. Paid video generation is NOT attempted.')
        url = fal_client.upload_file(str(image))
        print('AI_MOTION enabled: requesting ONE paid Wan 2.2 Turbo 480p clip.')
        result = fal_client.subscribe('fal-ai/wan/v2.2-a14b/image-to-video/turbo',
                                      arguments={'image_url':url,'prompt':prompt,
                                                 'resolution':'480p','aspect_ratio':'9:16'},
                                      client_timeout=900)
        clip_url = result['video']['url']
        r = requests.get(clip_url, timeout=180)
        r.raise_for_status()
        file = WORK/'motion.mp4'
        file.write_bytes(r.content)
    silent = WORK/'silent.mp4'
    if file:
        # Repeating a single paid motion shot conserves credits.
        cmd('ffmpeg','-y','-stream_loop','-1','-i',file,'-t',str(duration),
            '-vf','scale=720:1280:force_original_aspect_ratio=increase,crop=720:1280,setsar=1,fps=25,format=yuv420p',
            '-an','-c:v','libx264','-preset','veryfast','-crf','26',silent)
    else:
        cmd('ffmpeg','-y','-loop','1','-framerate','25','-i',image,'-t',str(duration),
            '-vf',"scale=720:1280:force_original_aspect_ratio=increase,crop=720:1280,zoompan=z='min(zoom+0.00025,1.16)':d=1:s=720x1280:fps=25,format=yuv420p",
            '-an','-c:v','libx264','-preset','veryfast','-crf','26',silent)
    return silent


def render(silent, duration):
    make_music(duration)
    style = 'FontName=DejaVu Sans,FontSize=21,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,Outline=2,Shadow=0,Alignment=2,MarginV=115'
    subtitle_filter = f"subtitles={WORK/'speech.srt'}:force_style='{style}'"
    logo = ROOT/'assets'/'logo.png'
    if logo.exists():
        # Overlay transparent logo near the upper right corner.
        vf = subtitle_filter
        cmd('ffmpeg','-y','-i',silent,'-i',WORK/'speech.mp3','-i',WORK/'ambient.wav',
            '-loop','1','-i',logo,
            '-filter_complex',f"[0:v]{vf}[v0];[3:v]scale=115:-1,format=rgba[logo];[v0][logo]overlay=W-w-28:30:shortest=1[v];[2:a]volume=0.25[m];[1:a][m]amix=inputs=2:duration=longest:dropout_transition=0[a]",
            '-map','[v]','-map','[a]','-t',str(duration),'-c:v','libx264','-preset','veryfast',
            '-crf','23','-pix_fmt','yuv420p','-c:a','aac','-b:a','128k','-movflags','+faststart',OUTPUT/'video.mp4')
    else:
        cmd('ffmpeg','-y','-i',silent,'-i',WORK/'speech.mp3','-i',WORK/'ambient.wav',
            '-vf',subtitle_filter,
            '-filter_complex','[2:a]volume=0.25[m];[1:a][m]amix=inputs=2:duration=longest:dropout_transition=0[a]',
            '-map','0:v','-map','[a]','-t',str(duration),'-c:v','libx264','-preset','veryfast',
            '-crf','23','-pix_fmt','yuv420p','-c:a','aac','-b:a','128k','-movflags','+faststart',OUTPUT/'video.mp4')
    print('FINAL MP4:', OUTPUT/'video.mp4', (OUTPUT/'video.mp4').stat().st_size, 'bytes')


def main():
    WORK.mkdir(exist_ok=True); OUTPUT.mkdir(exist_ok=True)
    pic = input_image()
    script = generate_script(pic)
    secs = audio_tts(script['narration'])
    still = visual(pic, script['visual_prompt'], secs)
    render(still, secs)

if __name__ == '__main__':
    main()
