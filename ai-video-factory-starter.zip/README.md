# AI Video Factory — 1 ảnh thành video TikTok từ iPhone

Quy trình: **upload 1 ảnh vào `inbox/`** → Gemini tự viết kịch bản → tạo giọng nam tiếng Việt và phụ đề với edge-tts → ghép nhạc nền tự tổng hợp và hiệu ứng ảnh với FFmpeg → lưu MP4 trên **GitHub Releases của kho Private**. Không cần mở laptop khi chạy.

## Thiết lập nhanh một lần

1. Vào https://github.com/new → tạo repo `ai-video-factory` → **Private** → khởi tạo README.
2. Tải file ZIP mà ChatGPT cung cấp. Trong repo GitHub vào `Code` → `Codespaces` → `Create codespace on main` (trên iPhone dùng Safari yêu cầu trang desktop nếu cần). Trong trình soạn thảo Codespaces upload file ZIP vào thư mục gốc, mở Terminal rồi chạy:
   ```bash
   unzip -o ai-video-factory-starter.zip && rm ai-video-factory-starter.zip
   git add -A && git commit -m 'Install AI video factory' && git push
   ```
   Nếu chưa thể dùng Codespaces, giải nén bằng ứng dụng Tệp của iPhone và upload lần lượt các file vào đúng đường dẫn trong repo bằng trang GitHub (bao gồm `.github/workflows/create-video.yml`).
3. Lấy Gemini API key tại https://aistudio.google.com/api-keys .
4. Repo `Settings` → `Secrets and variables` → `Actions` → `New repository secret` → Name: **GEMINI_API_KEY**, Value: khóa của bạn. **Không điền khóa vào mã nguồn.**
5. Bắt đầu: mở thư mục `inbox` trên GitHub → `Add file` → `Upload files` → đưa **duy nhất 1 ảnh JPG/PNG/HEIC** vào → `Commit changes`.
6. Vào `Actions` → `Create AI video from photo` → xem trạng thái. Khi xong mở `Releases` để tải `video.mp4` trên iPhone. MP4 cũng có ở Artifacts trong lần chạy (giữ 7 ngày).

## Bật chuyển động do AI sinh (tùy chọn, CÓ TÍNH PHÍ)

- Tạo tài khoản https://fal.ai, kiểm tra chính sách thanh toán trước khi cấp credits.
- Repo → `Settings` → `Secrets and variables` → `Actions` → `New repository secret` đặt `FAL_KEY`.
- Cũng ở `Actions` → tab `Variables` → `New repository variable`: `AI_MOTION` = `true`.
- Một lượt Wan 2.2 Turbo ở 480p khoảng $0.05 theo giá công bố; code chỉ gọi **một** lượt/video và lặp lại clip để hạn chế phí. Mặc định nếu không bật biến này thì **KHÔNG gửi ảnh sang fal** và **KHÔNG phát sinh phí tạo chuyển động**.

## Thêm logo

Để đặt logo cố định phía trên: upload `assets/logo.png` (ảnh PNG nền trong). Không có file này video vẫn chạy.

## Giới hạn hiện tại

- Bản tối thiểu không có website giao diện riêng; giao diện điều khiển là GitHub trên iPhone, dữ liệu lưu trong GitHub Private Repository.
- Không dùng Supabase và không tự đăng TikTok. Releases riêng tư, nhưng ảnh được gửi tới Gemini/Edge TTS và nếu bật Wan thì tới fal.
- Chỉ xử lý **1 ảnh một lần**. Trước khi tạo video kế tiếp, xóa ảnh cũ trong `inbox/` rồi upload ảnh mới; đừng để hai ảnh cùng tồn tại.
- Dịch vụ edge-tts phụ thuộc dịch vụ trực tuyến không chính thức; có thể lỗi hoặc thay đổi và không đảm bảo SLA. Nếu không tạo được voice, xem log tại Actions.
- GitHub Actions miễn phí có giới hạn phút dùng; Gemini API có giới hạn miễn phí và có thể yêu cầu tài khoản đủ điều kiện. Nếu hết hạn mức, lần chạy báo lỗi.
- Nhạc nền là nhạc ambient đơn giản được tổng hợp bằng thuật toán (không lấy nhạc người khác).
- Video mặc định **720x1280, MP4 H.264, có phụ đề, lời thoại, nhạc**. Chế độ mặc định chỉ sử dụng hiệu ứng zoom/pan chứ không phải tạo chuyển động mới bằng mô hình AI.

## Sự cố

- `Missing GEMINI_API_KEY` → bổ sung Secret.
- `HTTP 429` từ Gemini → đã hết hạn mức hoặc bị giới hạn tốc độ.
- `Expected exactly 1 image` → xóa bớt ảnh trong inbox.
- `edge-tts` lỗi → TTS bị nghẽn, thử chạy lại Actions (chế độ mặc định không có API video có phí).
- `gh release create` lỗi → kiểm tra `Settings` → `Actions` → `General` → `Workflow permissions`; phải cho phép `GITHUB_TOKEN` ghi nội dung. Hoặc lấy MP4 từ Artifacts của lần chạy.
